# importar o pandas
import pandas as pd

# importar a base de dados
#base = pd.read_excel('curitiba-excel-original.xlsx', sheet_name='curitiba')
base = pd.read_csv('curitiba-novo-menor.csv')

# converter as colunas para string
base['sexo'] = base['sexo'].astype(str)
base['municipio'] = base['municipio'].astype(str)
base['bairro'] = base['bairro'].astype(str)
base['doenca'] = base['doenca'].astype(str)

# dividir previsores e classe
previsores = base.iloc[:, 0:4].values
classe = base.iloc[:, 4].values

# transformar variáveis categóricas em variáveis discretas
from sklearn.preprocessing import LabelEncoder
labelencoder_previsores = LabelEncoder()
previsores[:,1] = labelencoder_previsores.fit_transform(previsores[:,1])
previsores[:,2] = labelencoder_previsores.fit_transform(previsores[:,2])
previsores[:,3] = labelencoder_previsores.fit_transform(previsores[:,3])

# usar label encoder para a classe
labelencoder_classe = LabelEncoder()
classe = labelencoder_classe.fit_transform(classe)

'''
# gerar mais atributos
from sklearn.preprocessing import OneHotEncoder
onehotencoder = OneHotEncoder(categorical_features = [1, 2, 3])
previsores = onehotencoder.fit_transform(previsores).toarray()
'''

'''
# escalonamento
from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
previsores = scaler.fit_transform(previsores)
'''

# divisão: base de dados de treinamento e base de dados de teste
from sklearn.cross_validation import train_test_split
previsores_treinamento, previsores_teste, classe_treinamento, classe_teste = train_test_split(previsores, classe, test_size=0.1, random_state=0)

# usar o naive bayes
from sklearn.naive_bayes import GaussianNB
classificador = GaussianNB()
classificador.fit(previsores_treinamento, classe_treinamento)

# fazer um predict com os testes
previsoes = classificador.predict(previsores_teste)

# ver estatísticas
from sklearn.metrics import confusion_matrix, accuracy_score
precisao = accuracy_score(classe_teste, previsoes) * 100
matriz = confusion_matrix(classe_teste, previsoes)
doencas = max(classe, key=int)
meta = 100/doencas

# tranformar base para encontrar os resultados
base['sexo'] = labelencoder_previsores.fit_transform(base['sexo'].fillna('NÃO INFORMADO'))
base['municipio'] = labelencoder_previsores.fit_transform(base['municipio'].fillna('NÃO INFORMADO'))
base['bairro'] = labelencoder_previsores.fit_transform(base['bairro'].fillna('NÃO INFORMADO'))
base['doenca'] = labelencoder_previsores.fit_transform(base['doenca'].fillna('NÃO INFORMADO'))

# fazer predict 
# ano, sexo, municipio, bairro
# curitiba, cidade industrial
resultado = classificador.predict([[1984,0,10,34]])
print(resultado)
# curitiba, sao braz
resultado = classificador.predict([[1990,1,10,72]])
print(resultado)
# pinhais, vargem grande
resultado = classificador.predict([[2000,1,14,80]])
print(resultado)

'''
86 DOR TORÁCICA AO RESPIRAR
170 OTALGIA
60 DIARREIA E GASTROENTERITE DE ORIGEM INFECCIOSA PRESUMIVEL
'''